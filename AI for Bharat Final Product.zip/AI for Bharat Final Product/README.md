# AgriNexus AI

**Track:** AI for Rural Innovation & Sustainable Systems  
Enterprise-grade AI for agriculture, market intelligence, and sustainability.

## Features

- **CEO Dashboard** — KPIs (farmers reached, water saved, carbon impact, market linkage), live weather & market tickers
- **AI Agent** — Groq-powered chat: crop advisory, irrigation, market timing, sustainability
- **Agentic workflows** — Multi-step reasoning (e.g. "Analyze my farm for this season")
- **Real-time** — Streaming responses, rotating tickers, last-updated timestamps

## Setup

1. **Environment**  
   Ensure `.env` in this folder contains:
   ```env
   VITE_GROQ_API_KEY=your_groq_api_key
   ```

2. **Install & run**
   ```bash
   npm install
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000).

3. **Build**
   ```bash
   npm run build
   npm run preview
   ```

## Docs

- `requirements.md` — Product requirements
- `design.md` — Design system and architecture

## Tech

- Vite, React 18, Tailwind CSS
- Groq API (Llama) for chat and agentic responses
