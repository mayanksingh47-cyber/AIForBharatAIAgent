import React from 'react'

export function CropCards({ crops = [] }) {
  if (!crops.length) return null
  return (
    <div className="mt-3 space-y-2">
      <p className="text-xs font-semibold uppercase text-slate-500">Recommended crops</p>
      <div className="grid gap-2 sm:grid-cols-2">
        {crops.map((c, i) => (
          <div
            key={i}
            className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm"
          >
            <p className="font-semibold text-slate-900">{c.name || c.crop || 'Crop'}</p>
            {c.season && <p className="text-xs text-slate-500">Season: {c.season}</p>}
            {c.reason && <p className="mt-1 text-xs text-slate-600">{c.reason}</p>}
            {c.water && <p className="mt-1 text-xs text-accent">Water: {c.water}</p>}
          </div>
        ))}
      </div>
    </div>
  )
}
