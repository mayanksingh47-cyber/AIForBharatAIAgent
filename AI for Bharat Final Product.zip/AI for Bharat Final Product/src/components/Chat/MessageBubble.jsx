import React from 'react'
import { getDisplayText } from '../../lib/parseAgentResponse'
import { AgentSteps } from './AgentSteps'
import { CropCards } from './CropCards'
import { ComparisonTable } from './ComparisonTable'
import { MessageActions } from './MessageActions'

export function MessageBubble({ message, onCopy, onAddToPlan, onSetReminder }) {
  const isUser = message.role === 'user'
  const displayText = isUser ? message.content : getDisplayText(message.content || '')
  const toolsUsed = message.toolsUsed
  const hasStructured = message.parsedSteps?.length || message.parsedRecommendation || message.parsedCrops?.length || message.parsedComparison || message.parsedSentiment

  return (
    <div className={`flex w-full justify-${isUser ? 'end' : 'start'}`}>
      <div className={`max-w-[95%] ${isUser ? '' : 'w-full'}`}>
        {!isUser && toolsUsed?.length > 0 && (
          <div className="mb-1 flex flex-wrap gap-1">
            {toolsUsed.map((t) => (
              <span
                key={t}
                className="inline-flex items-center rounded-md bg-accent/15 px-2 py-0.5 text-xs font-medium text-accent"
              >
                Used: {t}
              </span>
            ))}
          </div>
        )}
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser ? 'bg-primary text-white' : 'bg-slate-100 text-slate-900'
          }`}
        >
          {(displayText || hasStructured) && (
            <p className="whitespace-pre-wrap text-sm leading-relaxed">{displayText || '…'}</p>
          )}
          {!isUser && (
            <>
              {message.parsedSteps?.length > 0 && (
                <AgentSteps
                  visible
                  steps={message.parsedSteps}
                  recommendation={message.parsedRecommendation}
                />
              )}
              {!message.parsedSteps?.length && message.parsedRecommendation && (
                <div className="mt-3 rounded-lg border border-primary/20 bg-primary/5 p-3">
                  <p className="text-xs font-semibold uppercase text-primary">Recommendation</p>
                  <p className="mt-1 text-sm text-slate-800">{message.parsedRecommendation}</p>
                </div>
              )}
              {message.parsedCrops?.length > 0 && <CropCards crops={message.parsedCrops} />}
              {message.parsedComparison && <ComparisonTable data={message.parsedComparison} />}
              {message.parsedSentiment && (
                <div className="mt-2">
                  <span className="inline-flex items-center rounded-full bg-secondary/20 px-2.5 py-0.5 text-xs font-medium text-secondary">
                    Market sentiment: {message.parsedSentiment}
                  </span>
                </div>
              )}
              {message.parsedConfidence && (
                <div className="mt-2">
                  <span className="inline-flex items-center rounded-full bg-slate-200/80 px-2.5 py-0.5 text-xs font-medium text-slate-700">
                    Confidence: {message.parsedConfidence}
                  </span>
                </div>
              )}
              <MessageActions
                message={message}
                onCopy={onCopy}
                onAddToPlan={onAddToPlan}
                onSetReminder={onSetReminder}
              />
            </>
          )}
        </div>
      </div>
    </div>
  )
}
