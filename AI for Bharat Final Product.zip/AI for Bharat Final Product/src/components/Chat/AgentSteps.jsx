import React from 'react'

export function AgentSteps({ visible, steps = [], recommendation = null }) {
  if (!visible && !(steps?.length || recommendation)) return null
  const showStatic = visible && (!steps || steps.length === 0)
  const list = steps?.length ? steps : [
    { id: 1, title: 'Understanding your query', content: '' },
    { id: 2, title: 'Checking weather & soil context', content: '' },
    { id: 3, title: 'Generating recommendation', content: '' },
  ]

  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
      <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Agent steps</p>
      <ul className="space-y-2">
        {list.map((s, i) => (
          <li key={s.id || i} className="flex items-start gap-2 text-sm text-slate-700">
            <span className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${showStatic && i === list.length - 1 ? 'bg-slate-200 text-slate-600' : 'bg-primary text-white'}`}>
              {showStatic && i === list.length - 1 ? s.id : '✓'}
            </span>
            <span>
              <span className="font-medium">{s.title}</span>
              {s.content && <span className="block text-xs text-slate-500">{s.content}</span>}
            </span>
          </li>
        ))}
      </ul>
      {recommendation && (
        <div className="mt-4 rounded-lg border border-primary/20 bg-primary/5 p-3">
          <p className="text-xs font-semibold uppercase text-primary">Recommendation</p>
          <p className="mt-1 text-sm text-slate-800">{recommendation}</p>
        </div>
      )}
    </div>
  )
}
