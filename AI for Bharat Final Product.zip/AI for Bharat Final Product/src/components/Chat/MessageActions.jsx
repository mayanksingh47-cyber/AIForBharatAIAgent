import React, { useState } from 'react'

export function MessageActions({ message, onCopy, onAddToPlan, onSetReminder }) {
  const [copied, setCopied] = useState(false)
  const [added, setAdded] = useState(false)
  const isAssistant = message?.role === 'assistant'
  const text = message?.content || ''

  const handleCopy = () => {
    if (!text) return
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(true)
      onCopy?.()
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const handleAddToPlan = () => {
    const title = message?.parsedRecommendation ? 'Recommendation' : 'AI advice'
    const summary = (message?.parsedRecommendation || text).slice(0, 200)
    onAddToPlan?.({ type: 'recommendation', title, summary })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  const handleSetReminder = () => {
    const defaultTitle = message?.parsedRecommendation ? 'Follow up on recommendation' : 'Follow up on advice'
    const date = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
    onSetReminder?.({ title: defaultTitle, date, note: text.slice(0, 100) })
  }

  if (!isAssistant || (!text && !message?.parsedRecommendation)) return null

  return (
    <div className="mt-2 flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={handleCopy}
        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm transition hover:bg-slate-50"
      >
        {copied ? (
          <>✓ Copied</>
        ) : (
          <>
            <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h2m8 0h2a2 2 0 012 2v2m2 4v6a2 2 0 01-2 2h-8a2 2 0 01-2-2v-8" />
            </svg>
            Copy
          </>
        )}
      </button>
      {onAddToPlan && (
        <button
          type="button"
          onClick={handleAddToPlan}
          className="inline-flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-2.5 py-1.5 text-xs font-medium text-primary transition hover:bg-primary/10"
        >
          {added ? <>✓ Added to plan</> : <>+ Add to plan</>}
        </button>
      )}
      {onSetReminder && (
        <button
          type="button"
          onClick={handleSetReminder}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 shadow-sm transition hover:bg-slate-50"
        >
          <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          Set reminder
        </button>
      )}
    </div>
  )
}
