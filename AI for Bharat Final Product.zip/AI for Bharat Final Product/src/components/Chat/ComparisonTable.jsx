import React from 'react'

export function ComparisonTable({ data }) {
  if (!data?.items?.length) return null
  const factors = Object.keys(data.items[0]).filter((k) => k.toLowerCase() !== 'factor')
  const title = data.title || 'Comparison'

  return (
    <div className="mt-3 overflow-hidden rounded-lg border border-slate-200 bg-white">
      <p className="border-b border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold uppercase text-slate-600">
        {title}
      </p>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-200 bg-slate-50/80">
            <th className="px-3 py-2 text-left font-medium text-slate-600">Factor</th>
            {factors.map((f) => (
              <th key={f} className="px-3 py-2 text-left font-medium text-slate-700">{f}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.items.map((row, i) => (
            <tr key={i} className="border-b border-slate-100">
              <td className="px-3 py-2 font-medium text-slate-600">{row.factor || row.Factor || '—'}</td>
              {factors.map((f) => (
                <td key={f} className="px-3 py-2 text-slate-700">{row[f] ?? '—'}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
