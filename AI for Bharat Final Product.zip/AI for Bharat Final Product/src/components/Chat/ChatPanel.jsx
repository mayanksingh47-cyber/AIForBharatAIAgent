import React, { useState, useRef, useEffect } from 'react'
import { MessageBubble } from './MessageBubble'
import { AgentSteps } from './AgentSteps'
import { INDIAN_LANGUAGES, getLanguageByCode } from '../../lib/languages'

const QUICK_PROMPTS = [
  'Analyze my farm for this season — best crops and schedule',
  'Best crop for black soil in monsoon?',
  'When is the best time to sell wheat?',
  'Compare wheat vs mustard for my region',
  'Irrigation schedule for paddy in kharif',
  'मेरे इलाके में इस मौसम में क्या बोया जाए?',
  'காலம் மற்றும் மண் அடிப்படையில் சிறந்த பயிர்?',
  'আমার অঞ্চলে এই মরসুমে কী চাষ করব?',
]

const PLACEHOLDERS = {
  en: 'Ask about crops, market, weather...',
  hi: 'पूछें: फसल, मंडी, मौसम...',
  bn: 'জিজ্ঞাসা করুন: ফসল, বাজার, আবহাওয়া...',
  te: 'పంటలు, మార్కెట్, వాతావరణం గురించి అడగండి...',
  mr: 'विचारा: पीक, बाजार, हवामान...',
  ta: 'விவசாயம், சந்தை, வானிலை...',
  gu: 'પૂછો: પાક, બજાર, હવામાન...',
  kn: 'ಪ್ರಶ್ನಿಸಿ: ಬೆಳೆ, ಮಾರುಕಟ್ಟೆ, ಹವಾಮಾನ...',
  ml: 'ചോദിക്കുക: വിള, വിപണി, കാലാവസ്ഥ...',
  pa: 'ਪੁੱਛੋ: ਫਸਲ, ਮਾਰਕੀਟ, ਮੌਸਮ...',
  or: 'ପଚାରନ୍ତୁ: ଫସଲ, ବଜାର, ମୋସମ...',
  ur: 'پوچھیں: فصل، منڈی، موسم...',
  as: 'সোধক: শস্য, বজাৰ, বতৰ...',
  ne: 'सोध्नुहोस्: बाली, बजार, मौसम...',
}

function getPlaceholder(code) {
  return PLACEHOLDERS[code] || PLACEHOLDERS.en
}

const FOLLOW_UP_PROMPTS = [
  'When should I irrigate next?',
  'Compare with another crop',
  'What is MSP for this crop?',
  'Pest control for this crop?',
]

export function ChatPanel({ messages, streaming, error, sendMessage, clearChat, onClose, selectedLanguage, onLanguageChange, onAddToPlan, onSetReminder }) {
  const [input, setInput] = useState('')
  const [listening, setListening] = useState(false)
  const [langOpen, setLangOpen] = useState(false)
  const bottomRef = useRef(null)
  const recognitionRef = useRef(null)
  const langRef = useRef(null)

  const currentLang = selectedLanguage ? getLanguageByCode(selectedLanguage.code) : INDIAN_LANGUAGES[0]

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    function handleClickOutside(e) {
      if (langRef.current && !langRef.current.contains(e.target)) setLangOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    const text = input.trim()
    if (text) {
      sendMessage(text, { respondInLanguage: selectedLanguage || { code: 'en', name: 'English' } })
      setInput('')
    }
  }

  const startVoiceInput = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      alert('Voice input is not supported in this browser. Try Chrome or Edge.')
      return
    }
    if (listening) {
      recognitionRef.current?.stop()
      setListening(false)
      return
    }
    const code = currentLang?.code || 'en'
    const langMap = { en: 'en-IN', hi: 'hi-IN', bn: 'bn-IN', te: 'te-IN', ta: 'ta-IN', mr: 'mr-IN', gu: 'gu-IN', kn: 'kn-IN', ml: 'ml-IN', pa: 'pa-IN', or: 'or-IN', ur: 'ur-IN', as: 'as-IN', ne: 'ne-IN' }
    const recognition = new SpeechRecognition()
    recognition.lang = langMap[code] || 'en-IN'
    recognition.continuous = false
    recognition.interimResults = false
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript
      setInput((prev) => (prev ? prev + ' ' + transcript : transcript))
    }
    recognition.onend = () => setListening(false)
    recognition.onerror = () => setListening(false)
    recognitionRef.current = recognition
    recognition.start()
    setListening(true)
  }

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-200/80 bg-white shadow-2xl">
      <div className="flex items-center justify-between border-b border-slate-200/80 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" aria-hidden />
          <h3 className="font-semibold text-slate-900">AI Agent</h3>
          <div className="relative" ref={langRef}>
            <button
              type="button"
              onClick={() => setLangOpen((o) => !o)}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100"
              aria-expanded={langOpen}
              aria-label="Response language"
            >
              <span>🌐</span>
              <span className="max-w-[3.5rem] truncate sm:max-w-[5rem]">{currentLang?.native || 'English'}</span>
              <svg className={`h-3.5 w-3.5 text-slate-400 ${langOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {langOpen && (
              <ul className="absolute left-0 top-full z-50 mt-1 max-h-64 w-44 overflow-auto rounded-xl border border-slate-200 bg-white py-2 shadow-xl">
                {INDIAN_LANGUAGES.map((lang) => (
                  <li key={lang.code}>
                    <button
                      type="button"
                      onClick={() => {
                        setLangOpen(false)
                        onLanguageChange?.(lang)
                      }}
                      className={`flex w-full items-center gap-2 px-3 py-2 text-left text-xs transition ${currentLang?.code === lang.code ? 'bg-primary/10 font-medium text-primary' : 'text-slate-700 hover:bg-slate-50'}`}
                    >
                      {lang.native} ({lang.name})
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={clearChat}
            className="rounded-lg px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100"
            aria-label="Clear chat"
          >
            Clear
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 lg:hidden"
              aria-label="Close chat"
            >
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {messages.length === 0 ? (
          <div className="space-y-4">
            <p className="text-sm text-slate-500">
              Ask in any Indian language. Agent responds in the language you select. Use voice or type.
            </p>
            <p className="text-xs text-slate-400">Agent uses Weather & Market tools when relevant.</p>
            <p className="text-xs font-medium text-slate-500">Quick prompts:</p>
            <div className="flex flex-wrap gap-2">
              {QUICK_PROMPTS.map((prompt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => sendMessage(prompt, { respondInLanguage: selectedLanguage || { code: 'en', name: 'English' } })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-left text-xs text-slate-700 transition hover:border-primary/30 hover:bg-primary/5 hover:text-primary"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, i) => (
              <MessageBubble
                key={i}
                message={msg}
                onAddToPlan={onAddToPlan}
                onSetReminder={onSetReminder}
              />
            ))}
            {!streaming && messages.length > 0 && messages[messages.length - 1]?.role === 'assistant' && (
              <div className="flex flex-wrap gap-2">
                <span className="text-xs font-medium text-slate-500">Follow up:</span>
                {FOLLOW_UP_PROMPTS.map((prompt, j) => (
                  <button
                    key={j}
                    type="button"
                    onClick={() => sendMessage(prompt, { respondInLanguage: selectedLanguage || { code: 'en', name: 'English' } })}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-600 shadow-sm transition hover:border-primary/30 hover:bg-primary/5 hover:text-primary"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            )}
            {streaming && <AgentSteps visible />}
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="border-t border-slate-200/80 p-4">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={startVoiceInput}
            className={`shrink-0 rounded-xl p-2.5 transition ${listening ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            title={listening ? 'Stop listening' : 'Voice input'}
            aria-label={listening ? 'Stop listening' : 'Voice input'}
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v0h14z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19v-5m0 0V8a3 3 0 006 0v6" />
            </svg>
          </button>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={getPlaceholder(currentLang?.code)}
            className="flex-1 rounded-xl border border-slate-200 px-4 py-2.5 text-sm placeholder-slate-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            disabled={streaming}
            aria-label="Message"
          />
          <button
            type="submit"
            disabled={streaming || !input.trim()}
            className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-primary-dark disabled:opacity-50"
            aria-label="Send"
          >
            {streaming ? (
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 animate-pulse rounded-full bg-white" /> Sending
              </span>
            ) : (
              'Send'
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
