import React from 'react'

const ACTIONS = [
  { label: 'Get weather', prompt: 'Weather and soil moisture for my region', icon: '🌤️' },
  { label: 'Check prices', prompt: 'Current mandi prices for wheat and rice', icon: '📊' },
  { label: 'Plan sowing', prompt: 'Best crops to sow this month in North India', icon: '🌱' },
  { label: 'Price alert', labelAlt: 'Set price alert', prompt: 'When is the best time to sell wheat?', icon: '🔔' },
]

export function QuickActionsCard({ onAction, onOpenChat }) {
  const handleClick = (action) => {
    onOpenChat?.()
    setTimeout(() => onAction?.(action.prompt), 100)
  }

  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
      <h3 className="text-lg font-bold text-slate-900">Quick actions</h3>
      <p className="mt-1 text-sm text-slate-500">One tap to ask the AI Agent</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {ACTIONS.map((a, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleClick(a)}
            className="flex items-center gap-3 rounded-xl border border-slate-200/80 bg-slate-50/50 p-4 text-left transition hover:border-primary/30 hover:bg-primary/5"
          >
            <span className="text-2xl" aria-hidden>{a.icon}</span>
            <span className="text-sm font-medium text-slate-700">{a.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
