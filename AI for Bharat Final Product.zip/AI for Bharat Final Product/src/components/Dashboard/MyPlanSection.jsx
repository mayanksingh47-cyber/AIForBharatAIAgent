import React from 'react'

export function MyPlanSection({ items = [], reminders = [], onRemoveItem, onRemoveReminder }) {
  const hasItems = items.length > 0 || reminders.length > 0

  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-slate-900">My plan</h3>
        <span className="text-xs text-slate-500">Saved from AI Agent</span>
      </div>
      <p className="mt-1 text-sm text-slate-500">Recommendations and reminders you saved. Take action when ready.</p>
      {!hasItems ? (
        <p className="mt-4 text-sm text-slate-400">No saved items yet. Use &quot;Add to plan&quot; or &quot;Set reminder&quot; on any AI response.</p>
      ) : (
        <div className="mt-4 space-y-4">
          {items.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Saved</h4>
              <ul className="mt-2 space-y-2">
                {items.slice(0, 5).map((item) => (
                  <li key={item.id} className="flex items-start justify-between gap-2 rounded-lg border border-slate-100 bg-slate-50/50 p-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-900">{item.title}</p>
                      {item.summary && <p className="mt-0.5 truncate text-xs text-slate-500">{item.summary}</p>}
                    </div>
                    <button
                      type="button"
                      onClick={() => onRemoveItem?.(item.id)}
                      className="shrink-0 rounded p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-600"
                      aria-label="Remove"
                    >
                      <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {reminders.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Reminders</h4>
              <ul className="mt-2 space-y-2">
                {reminders.slice(0, 5).map((r) => (
                  <li key={r.id} className="flex items-start justify-between gap-2 rounded-lg border border-slate-100 bg-amber-50/50 p-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-slate-900">{r.title}</p>
                      <p className="mt-0.5 text-xs text-slate-500">By {new Date(r.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onRemoveReminder?.(r.id)}
                      className="shrink-0 rounded p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-600"
                      aria-label="Remove reminder"
                    >
                      <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
