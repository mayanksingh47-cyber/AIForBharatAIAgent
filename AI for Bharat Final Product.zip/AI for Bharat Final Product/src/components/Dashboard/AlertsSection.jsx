import React from 'react'

export function AlertsSection({ alerts = [], onRemoveAlert, onAddAlert }) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-slate-900">Alerts</h3>
        {onAddAlert && (
          <button
            type="button"
            onClick={() => onAddAlert({ type: 'price', title: 'Wheat price alert', crop: 'Wheat', target: '₹2,500/qtl' })}
            className="text-sm font-medium text-primary hover:underline"
          >
            + Add alert
          </button>
        )}
      </div>
      <p className="mt-1 text-sm text-slate-500">Price and weather alerts (saved in browser)</p>
      {alerts.length === 0 ? (
        <p className="mt-4 text-sm text-slate-400">No alerts. Add a price or weather alert to get notified.</p>
      ) : (
        <ul className="mt-4 space-y-2">
          {alerts.slice(0, 5).map((a) => (
            <li key={a.id} className="flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50/50 px-3 py-2">
              <span className="text-sm text-slate-700">{a.title} {a.crop && `— ${a.crop}`}</span>
              <button
                type="button"
                onClick={() => onRemoveAlert?.(a.id)}
                className="rounded p-1 text-slate-400 hover:text-slate-600"
                aria-label="Remove alert"
              >
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
