import React from 'react'

export function AIInsightsCard({ insights = [], loading, error, refetch }) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-slate-900">AI-recommended actions</h2>
        {refetch && (
          <button
            type="button"
            onClick={refetch}
            className="text-xs font-medium text-primary hover:underline"
          >
            Refresh
          </button>
        )}
      </div>
      <p className="mt-1 text-xs text-slate-500">Personalized for your region and season (refreshes every 5 min)</p>
      {loading ? (
        <div className="mt-4 flex gap-2">
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" style={{ animationDelay: '0.2s' }} />
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" style={{ animationDelay: '0.4s' }} />
        </div>
      ) : error ? (
        <p className="mt-4 text-sm text-amber-600">{error}</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {insights.map((line, i) => (
            <li key={i} className="flex gap-3 text-sm text-slate-700">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-semibold text-primary">
                {i + 1}
              </span>
              {line}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
