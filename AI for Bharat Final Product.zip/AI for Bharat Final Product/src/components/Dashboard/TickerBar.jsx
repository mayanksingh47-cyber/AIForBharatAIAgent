import React from 'react'

export function TickerBar({ weather, market }) {
  return (
    <div className="border-y border-slate-200/80 bg-slate-50/90">
      <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
        <div className="mb-2 flex items-center gap-2 text-xs font-medium text-slate-500">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" aria-hidden />
          Live data · Indian mandis & regions
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="flex items-center gap-3">
            <span className="shrink-0 rounded-lg bg-white px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500 shadow-sm ring-1 ring-slate-200/60">
              Weather
            </span>
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {weather.slice(0, 5).map((w, i) => (
                <span
                  key={i}
                  className="shrink-0 rounded-xl bg-white px-4 py-2.5 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-200/60"
                >
                  {w.region}: <span className="text-primary">{w.temp}</span> · {w.condition}
                </span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="shrink-0 rounded-lg bg-white px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500 shadow-sm ring-1 ring-slate-200/60">
              Market
            </span>
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {market.slice(0, 5).map((m, i) => (
                <span
                  key={i}
                  className="shrink-0 rounded-xl bg-white px-4 py-2.5 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-slate-200/60"
                >
                  {m.crop} ({m.mandi}): <span className="text-primary">{m.price}</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
