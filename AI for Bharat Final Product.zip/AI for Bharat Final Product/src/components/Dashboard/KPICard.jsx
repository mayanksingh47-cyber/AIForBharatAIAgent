import React from 'react'

const trendUp = (
  <svg className="h-4 w-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
)
const trendDown = (
  <svg className="h-4 w-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 17h8m0 0v-8m0 8l-8-8-4 4-6-6" />
  </svg>
)

export function KPICard({ title, value, subtitle, trend, icon: Icon }) {
  return (
    <div className="group animate-slide-up rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm transition-all duration-200 hover:border-primary/20 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex items-start justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900">{value}</p>
          {subtitle && <p className="mt-1 text-xs text-slate-500">{subtitle}</p>}
          {trend !== undefined && (
            <div className="mt-3 flex items-center gap-1.5">
              {trend === 'up' ? trendUp : trendDown}
              <span className="text-xs font-medium text-slate-600">vs last month</span>
            </div>
          )}
        </div>
        {Icon && (
          <div className="ml-4 flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/15 to-primary/5 text-primary transition group-hover:from-primary/20 group-hover:to-primary/10">
            <Icon className="h-7 w-7" />
          </div>
        )}
      </div>
    </div>
  )
}
