import React from 'react'

export function Footer({ lastUpdated }) {
  return (
    <footer className="border-t border-slate-200/80 bg-slate-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="text-lg font-semibold text-white">AgriNexus AI</h3>
            <p className="mt-2 text-sm">
              Intelligence for Rural & Sustainable Systems. AI for Bharat — all Indian languages.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Product</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#dashboard" className="hover:text-white">Dashboard</a></li>
              <li><a href="#features" className="hover:text-white">Features</a></li>
              <li><a href="#insights" className="hover:text-white">AI Insights</a></li>
              <li><a href="#privacy" className="hover:text-white">Privacy</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400">Track</h4>
            <p className="mt-3 text-sm">
              AI for Rural Innovation & Sustainable Systems
            </p>
          </div>
          <div>
            {lastUpdated && (
              <p className="text-xs text-slate-500">
                Data last updated: {lastUpdated.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} IST
              </p>
            )}
          </div>
        </div>
        <div className="mt-10 border-t border-slate-800 pt-8 text-center text-sm text-slate-500">
          © {new Date().getFullYear()} AgriNexus AI. Built for Bharat.
        </div>
      </div>
    </footer>
  )
}
