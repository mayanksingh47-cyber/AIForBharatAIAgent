import React, { useState, useRef, useEffect } from 'react'
import { INDIAN_LANGUAGES, getLanguageByCode } from '../../lib/languages'

export function Header({ onOpenChat, chatOpen, selectedLanguage, onLanguageChange }) {
  const [langOpen, setLangOpen] = useState(false)
  const langRef = useRef(null)

  useEffect(() => {
    function handleClickOutside(e) {
      if (langRef.current && !langRef.current.contains(e.target)) setLangOpen(false)
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const current = selectedLanguage ? getLanguageByCode(selectedLanguage.code) : INDIAN_LANGUAGES[0]

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/95 shadow-sm backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary-dark text-white shadow-lg shadow-primary/20">
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">AgriNexus AI</h1>
            <p className="hidden text-xs text-slate-500 sm:block">Intelligence for Rural & Sustainable Systems</p>
          </div>
        </div>

        <nav className="flex items-center gap-2">
          <a href="#dashboard" className="rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900">
            Dashboard
          </a>
          <a href="#features" className="hidden rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 sm:block">
            Features
          </a>
          <a href="#my-plan" className="rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900">
            My plan
          </a>
          <a href="#insights" className="rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900">
            Insights
          </a>

          {onLanguageChange && (
            <div className="relative" ref={langRef}>
              <button
                type="button"
                onClick={() => setLangOpen((o) => !o)}
                className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
                aria-expanded={langOpen}
                aria-haspopup="listbox"
                aria-label="Select language"
              >
                <span className="text-slate-500" aria-hidden>🌐</span>
                <span className="max-w-[4rem] truncate sm:max-w-[6rem]">{current.native || current.name}</span>
                <svg className={`h-4 w-4 text-slate-400 transition ${langOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {langOpen && (
                <ul
                  className="absolute right-0 top-full z-50 mt-1 max-h-72 w-52 overflow-auto rounded-xl border border-slate-200 bg-white py-2 shadow-xl"
                  role="listbox"
                >
                  {INDIAN_LANGUAGES.map((lang) => (
                    <li key={lang.code} role="option" aria-selected={current.code === lang.code}>
                      <button
                        type="button"
                        onClick={() => {
                          onLanguageChange(lang)
                          setLangOpen(false)
                        }}
                        className={`flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm transition ${current.code === lang.code ? 'bg-primary/10 font-medium text-primary' : 'text-slate-700 hover:bg-slate-50'}`}
                      >
                        <span className="min-w-[2.5rem]">{lang.native}</span>
                        <span className="text-slate-500">({lang.name})</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          <button
            onClick={onOpenChat}
            className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold shadow-md transition ${chatOpen ? 'bg-primary text-white' : 'bg-primary text-white hover:bg-primary-dark hover:shadow-lg'}`}
            aria-label="Open AI Agent"
          >
            <span className="hidden sm:inline">AI Agent</span>
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </button>
        </nav>
      </div>
    </header>
  )
}
