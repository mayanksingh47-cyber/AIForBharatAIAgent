import React, { useState } from 'react'
import { Header } from './components/layout/Header'
import { Footer } from './components/layout/Footer'
import { Hero } from './components/Dashboard/Hero'
import { KPICard } from './components/Dashboard/KPICard'
import { TickerBar } from './components/Dashboard/TickerBar'
import { FeaturesSection } from './components/Dashboard/FeaturesSection'
import { ChatPanel } from './components/Chat/ChatPanel'
import { AIInsightsCard } from './components/Dashboard/AIInsightsCard'
import { useGroqChat } from './hooks/useGroqChat'
import { useTickerData } from './hooks/useTickerData'
import { useDashboardInsights } from './hooks/useDashboardInsights'
import { useMyPlan } from './hooks/useMyPlan'
import { INDIAN_LANGUAGES } from './lib/languages'
import { QuickActionsCard } from './components/Dashboard/QuickActionsCard'
import { MyPlanSection } from './components/Dashboard/MyPlanSection'
import { AlertsSection } from './components/Dashboard/AlertsSection'

const KPI_ICON = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
)
const DROP_ICON = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
)
const LEAF_ICON = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
  </svg>
)
const CART_ICON = () => (
  <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
  </svg>
)

export default function App() {
  const [chatOpen, setChatOpen] = useState(false)
  const [selectedLanguage, setSelectedLanguage] = useState(INDIAN_LANGUAGES[0])
  const groq = useGroqChat()
  const ticker = useTickerData()
  const dashboardInsights = useDashboardInsights()
  const myPlan = useMyPlan()

  const openChatAndSend = (prompt) => {
    setChatOpen(true)
    setTimeout(() => groq.sendMessage(prompt, { respondInLanguage: selectedLanguage }), 150)
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/50">
      <Header
        onOpenChat={() => setChatOpen((o) => !o)}
        chatOpen={chatOpen}
        selectedLanguage={selectedLanguage}
        onLanguageChange={setSelectedLanguage}
      />
      <main className="flex-1">
        <Hero />
        <TickerBar weather={ticker.weather} market={ticker.market} />
        <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wider text-slate-500">Key metrics</h2>
          <p className="mb-8 text-2xl font-bold text-slate-900">Dashboard overview</p>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <KPICard title="Farmers reached" value="12,450" subtitle="This month" trend="up" icon={KPI_ICON} />
            <KPICard title="Water saved (est.)" value="2.4M L" subtitle="Irrigation advisory" trend="up" icon={DROP_ICON} />
            <KPICard title="Carbon impact" value="-18%" subtitle="vs baseline" trend="up" icon={LEAF_ICON} />
            <KPICard title="Market linkage" value="8,200" subtitle="Sell recommendations" trend="up" icon={CART_ICON} />
          </div>
          <QuickActionsCard onAction={(prompt) => openChatAndSend(prompt)} onOpenChat={() => setChatOpen(true)} />
        </section>

        <section id="my-plan" className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wider text-slate-500">Your actions</h2>
          <p className="mb-6 text-2xl font-bold text-slate-900">My plan & alerts</p>
          <div className="grid gap-6 lg:grid-cols-2">
            <MyPlanSection
              items={myPlan.items}
              reminders={myPlan.reminders}
              onRemoveItem={myPlan.removeFromPlan}
              onRemoveReminder={myPlan.removeReminder}
            />
            <AlertsSection
              alerts={myPlan.alerts}
              onRemoveAlert={myPlan.removeAlert}
              onAddAlert={myPlan.addAlert}
            />
          </div>
        </section>

        <FeaturesSection />

        <section id="insights" className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wider text-slate-500">AI insights</h2>
          <p className="mb-8 text-2xl font-bold text-slate-900">Recommended actions</p>
          <AIInsightsCard
            insights={dashboardInsights.insights}
            loading={dashboardInsights.loading}
            error={dashboardInsights.error}
            refetch={dashboardInsights.refetch}
          />
          <div className="mt-8 rounded-2xl border border-slate-200/80 bg-white p-8 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900">Talk to the AI Agent</h3>
            <p className="mt-2 text-slate-600">
              Use the <button type="button" onClick={() => setChatOpen(true)} className="font-semibold text-primary hover:underline">AI Agent</button> for crop advice, market timing, and sustainability. Choose any Indian language for the response. Agent uses Weather & Market tools and supports voice input. Try: &quot;Analyze my farm for this season&quot;, &quot;Best time to sell wheat&quot;, or ask in हिंदी, தமிழ், বাংলা, or any supported language.
            </p>
          </div>
        </section>
      </main>
      <Footer lastUpdated={ticker.lastUpdated} />

      {chatOpen && (
        <div className="fixed inset-0 z-50 flex justify-end lg:inset-y-0 lg:right-0 lg:left-auto">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm lg:bg-transparent" onClick={() => setChatOpen(false)} aria-hidden />
          <aside className="relative z-10 flex h-full w-full max-w-lg flex-col bg-white lg:border-l lg:shadow-2xl">
            <div className="flex h-full flex-col p-4 lg:p-5">
              <ChatPanel
                messages={groq.messages}
                streaming={groq.streaming}
                error={groq.error}
                sendMessage={groq.sendMessage}
                clearChat={groq.clearChat}
                onClose={() => setChatOpen(false)}
                selectedLanguage={selectedLanguage}
                onLanguageChange={setSelectedLanguage}
                onAddToPlan={myPlan.addToPlan}
                onSetReminder={myPlan.setReminder}
              />
            </div>
          </aside>
        </div>
      )}
    </div>
  )
}
