import { useState, useEffect, useCallback } from 'react'

const STORAGE_ITEMS = 'agrinexus_plan_items'
const STORAGE_REMINDERS = 'agrinexus_reminders'
const STORAGE_ALERTS = 'agrinexus_alerts'

function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch (_) {
    return fallback
  }
}

function saveJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (_) {}
}

export function useMyPlan() {
  const [items, setItems] = useState(() => loadJson(STORAGE_ITEMS, []))
  const [reminders, setReminders] = useState(() => loadJson(STORAGE_REMINDERS, []))
  const [alerts, setAlerts] = useState(() => loadJson(STORAGE_ALERTS, []))

  useEffect(() => {
    saveJson(STORAGE_ITEMS, items)
  }, [items])
  useEffect(() => {
    saveJson(STORAGE_REMINDERS, reminders)
  }, [reminders])
  useEffect(() => {
    saveJson(STORAGE_ALERTS, alerts)
  }, [alerts])

  const addToPlan = useCallback((payload) => {
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      type: payload.type || 'recommendation',
      title: payload.title || 'Saved recommendation',
      summary: payload.summary || '',
      addedAt: new Date().toISOString(),
    }
    setItems((prev) => [entry, ...prev].slice(0, 50))
    return entry
  }, [])

  const removeFromPlan = useCallback((id) => {
    setItems((prev) => prev.filter((i) => i.id !== id))
  }, [])

  const setReminder = useCallback((payload) => {
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      title: payload.title || 'Reminder',
      date: payload.date || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      note: payload.note || '',
      createdAt: new Date().toISOString(),
    }
    setReminders((prev) => [entry, ...prev].slice(0, 30))
    return entry
  }, [])

  const removeReminder = useCallback((id) => {
    setReminders((prev) => prev.filter((r) => r.id !== id))
  }, [])

  const addAlert = useCallback((payload) => {
    const entry = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      type: payload.type || 'price',
      title: payload.title || 'Price alert',
      crop: payload.crop || '',
      target: payload.target || '',
      createdAt: new Date().toISOString(),
    }
    setAlerts((prev) => [entry, ...prev].slice(0, 20))
    return entry
  }, [])

  const removeAlert = useCallback((id) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id))
  }, [])

  return {
    items,
    reminders,
    alerts,
    addToPlan,
    removeFromPlan,
    setReminder,
    removeReminder,
    addAlert,
    removeAlert,
  }
}
