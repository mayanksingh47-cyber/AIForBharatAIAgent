import { useState, useCallback } from 'react'
import { streamGroqChat } from '../lib/groq'
import { getToolContext, buildUserMessageWithTools } from '../lib/agentTools'
import { parseAgentSteps, parseCropsJson, parseComparisonJson, parseSentiment, parseConfidence } from '../lib/parseAgentResponse'

export function useGroqChat() {
  const [messages, setMessages] = useState([])
  const [streaming, setStreaming] = useState(false)
  const [error, setError] = useState(null)

  const sendMessage = useCallback(async (content, options = {}) => {
    const rawContent = (content || '').trim()
    if (!rawContent || streaming) return
    setError(null)

    const toolContext = getToolContext(rawContent)
    let userContentForApi = buildUserMessageWithTools(rawContent, toolContext)
    const lang = options.respondInLanguage
    if (lang && lang.code && lang.code !== 'en')
      userContentForApi += `\n[Respond entirely in ${lang.name} (${lang.code}), using the native script for that language.]`
    const userMsg = { role: 'user', content: rawContent }
    setMessages((prev) => [...prev, userMsg])

    const assistantMsg = { role: 'assistant', content: '', toolsUsed: toolContext.toolsUsed }
    setMessages((prev) => [...prev, assistantMsg])

    const historyForApi = messages.map((m) => ({ role: m.role, content: m.role === 'user' ? m.content : m.content }))
    const apiMessages = [
      ...historyForApi,
      { role: 'user', content: userContentForApi },
    ]

    setStreaming(true)

    await streamGroqChat(
      apiMessages,
      (chunk) => {
        setMessages((prev) => {
          const next = [...prev]
          const last = next[next.length - 1]
          if (last?.role === 'assistant') next[next.length - 1] = { ...last, content: last.content + chunk }
          return next
        })
      },
      (err) => {
        setStreaming(false)
        if (err) {
          setError(err.message)
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last?.role === 'assistant') next[next.length - 1] = { ...last, content: (last.content || '') + '\n\n[Error: ' + err.message + ']' }
            return next
          })
        } else {
          setMessages((prev) => {
            const next = [...prev]
            const last = next[next.length - 1]
            if (last?.role !== 'assistant' || !last.content) return next
            const fullText = last.content
            const { steps, recommendation } = parseAgentSteps(fullText)
            const crops = parseCropsJson(fullText)
            const comparison = parseComparisonJson(fullText)
            const sentiment = parseSentiment(fullText)
            const confidence = parseConfidence(fullText)
            next[next.length - 1] = {
              ...last,
              parsedSteps: steps.length ? steps : null,
              parsedRecommendation: recommendation || null,
              parsedCrops: crops.length ? crops : null,
              parsedComparison: comparison || null,
              parsedSentiment: sentiment || null,
              parsedConfidence: confidence || null,
            }
            return next
          })
        }
      }
    )
    setStreaming(false)
  }, [messages, streaming])

  const clearChat = useCallback(() => {
    setMessages([])
    setError(null)
  }, [])

  return { messages, streaming, error, sendMessage, clearChat }
}
