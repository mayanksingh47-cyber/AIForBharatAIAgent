import { useState, useEffect, useCallback } from 'react'
import { sendGroqMessage } from '../lib/groq'

const CACHE_MS = 5 * 60 * 1000 // 5 min

const FALLBACK_INSIGHTS = [
  'Complete rabi harvest and prepare land for kharif; consider short-duration varieties if monsoon is delayed.',
  'Check mandi prices for wheat and mustard; current trends favor selling in the next 2 weeks in North India.',
  'Schedule irrigation for summer crops; use soil moisture data to avoid over-irrigation and save water.',
]

export function useDashboardInsights() {
  const [insights, setInsights] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [fetchedAt, setFetchedAt] = useState(null)

  const fetchInsights = useCallback(async () => {
    const apiKey = import.meta.env.VITE_GROQ_API_KEY
    if (!apiKey) {
      setInsights(FALLBACK_INSIGHTS)
      setLoading(false)
      return
    }
    setLoading(true)
    setError(null)
    try {
      const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })
      const prompt = `Today is ${today}. Region: North India (Punjab, Haryana, UP). Give exactly 3 one-line actionable recommendations for farmers. Number them 1. 2. 3. Be specific (crops, mandi, irrigation, sowing). No other text.`
      const content = await sendGroqMessage([{ role: 'user', content: prompt }], { max_tokens: 256 })
      const lines = content.split(/\n/).map((s) => s.replace(/^\d+\.\s*/, '').trim()).filter(Boolean)
      const top3 = (lines.length >= 3 ? lines.slice(0, 3) : lines.length > 0 ? lines : FALLBACK_INSIGHTS)
      setInsights(top3)
      setFetchedAt(Date.now())
    } catch (e) {
      setError(e.message)
      setInsights(FALLBACK_INSIGHTS)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (fetchedAt && Date.now() - fetchedAt < CACHE_MS) return
    fetchInsights()
  }, [fetchInsights, fetchedAt])

  return { insights, loading, error, refetch: fetchInsights }
}
