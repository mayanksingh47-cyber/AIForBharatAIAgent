import { useState, useEffect } from 'react'

const WEATHER_ITEMS = [
  { region: 'Punjab / Haryana', temp: '26–30°C', condition: 'Partly cloudy', humidity: '58%' },
  { region: 'MP / Chhattisgarh', temp: '30–34°C', condition: 'Clear', humidity: '52%' },
  { region: 'Karnataka / Tamil Nadu', temp: '28–32°C', condition: 'Humid', humidity: '78%' },
  { region: 'West Bengal / Bihar', temp: '28–31°C', condition: 'Humid', humidity: '82%' },
  { region: 'Gujarat / Rajasthan', temp: '31–35°C', condition: 'Sunny', humidity: '48%' },
]

const MARKET_ITEMS = [
  { crop: 'Wheat', mandi: 'Azadpur (Delhi)', price: '₹2,520/qtl', trend: 'up' },
  { crop: 'Rice', mandi: 'Vashi (Mumbai)', price: '₹3,200/qtl', trend: 'stable' },
  { crop: 'Mustard', mandi: 'Rajasthan', price: '₹5,280/qtl', trend: 'up' },
  { crop: 'Soybean', mandi: 'Indore (MP)', price: '₹4,350/qtl', trend: 'neutral' },
  { crop: 'Groundnut', mandi: 'Rajkot (Gujarat)', price: '₹6,100/qtl', trend: 'up' },
  { crop: 'Onion', mandi: 'Nashik (Maharashtra)', price: '₹2,100/qtl', trend: 'down' },
  { crop: 'Maize', mandi: 'Dharwad (Karnataka)', price: '₹2,150/qtl', trend: 'down' },
  { crop: 'Chilli', mandi: 'Guntur (AP)', price: '₹18,500/qtl', trend: 'up' },
]

function rotate(arr, offset) {
  const i = offset % arr.length
  return [...arr.slice(i), ...arr.slice(0, i)]
}

export function useTickerData() {
  const [weather, setWeather] = useState(WEATHER_ITEMS)
  const [market, setMarket] = useState(MARKET_ITEMS)
  const [lastUpdated, setLastUpdated] = useState(new Date())

  useEffect(() => {
    const t = setInterval(() => {
      setWeather((prev) => rotate(prev, 1))
      setMarket((prev) => rotate(prev, 1))
      setLastUpdated(new Date())
    }, 5000)
    return () => clearInterval(t)
  }, [])

  return { weather, market, lastUpdated }
}
